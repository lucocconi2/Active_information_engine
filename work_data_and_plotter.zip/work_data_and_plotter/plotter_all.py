import numpy as np
import matplotlib.pyplot as plt

# ## Import simulation parameters T gamma nu alpha dt D"
# with open('highpecletrun_params.txt') as g:
#     lines = g.readlines()
#     paramarray = [float(line.split()[0]) for line in lines]
#     T = paramarray[0]
#     gamma = paramarray[1]
#     nu = paramarray[2]
#     alpha = paramarray[3]
#     dt = paramarray[4]
#     D = paramarray[5]

T = 300000
gamma = 1
nu = 1
alpha = 1
D = 1
numvals = 400
xcritvals=60

# Generate xcrit array
alphaarray = np.logspace(-4, 3, num=numvals, endpoint=True)
pecarray = 1/alphaarray

## Import work data from text files
inputdatafile = 'alldata_highpec_.txt'
with open(inputdatafile) as f:
    lines = f.readlines()
    indices = np.array([int(line.split()[0]) for line in lines])
    workvals = np.array([float(line.split()[1]) for line in lines])

## Calculate maximum work extracted for each value of Pe
separatedwork = np.split(workvals, numvals)
maxima = np.amax(separatedwork, axis=1)

#################################################################
#############Plot figure - log(power) vs log(Pe) ################
#################################################################
fig = plt.figure()
ax1 = fig.add_subplot(111)

ax1.set_title("power vs peclet")
ax1.set_xlabel('peclet')
ax1.set_ylabel('Average power output')
ax1.set_xscale('log')
ax1.set_yscale('log')
ax1.set_xlim(np.min(pecarray), np.max(pecarray))
ax1.set_ylim(0.00001, 1.1)

# # Generate points to plot
# datapairs = np.array([pecarray[indices-1], highworkvals/(1*1/4)])
# print(datapairs[0])
#
# ax1.scatter(datapairs[0],  1-datapairs[1], c='black', marker=',', alpha=0.3)
# ax1.plot(datapairs[0][150:], 1- datapairs[0][150:]/8, c='olive', marker=',')
# ax1.plot(datapairs[0][:60],  1-(1 - 4/(datapairs[0][:60])), c='olive', marker=',')

ax1.plot(pecarray, maxima*4, c='olive', marker=',', label='Simulation data')
ax1.plot(pecarray[228:], pecarray[228:]/8, c='k', marker=',', label='Theoretical prediction')
ax1.plot(pecarray[:100], (1-4*1/pecarray[:100]), c='k', marker=',')
ax1.set_xlim(0.01, 10000)
ax1.set_ylim(10**(-3.5), 1.1)

leg = ax1.legend()
ax1.set_title("Power vs Pe")
ax1.legend()
plt.savefig('logplot_lowpec.pdf')
# plt.show()

#################################################################
#############  Plot figure - power vs log(Pe) ################
#################################################################
fig = plt.figure()
ax1 = fig.add_subplot(111)

ax1.set_title("power vs peclet")
ax1.set_xlabel('peclet')
ax1.set_ylabel('Average power output')
ax1.set_xscale('log')
ax1.set_yscale('linear')
ax1.set_xlim(np.min(pecarray), np.max(pecarray))
ax1.set_ylim(0.00001, 1.1)

ax1.plot(pecarray, maxima*4, c='k', marker=',', label='Simulation data')
ax1.plot(pecarray[228:], pecarray[228:]/8, c='blue', marker=',', label='Theoretical prediction')
# ax1.plot(pecarray[:100], (1-4*1/pecarray[:100]), c='k', marker=',')
ax1.plot(pecarray,  np.ones(len(pecarray)), c='red', alpha=0.7, linewidth=0.3)
ax1.plot(pecarray,  np.zeros(len(pecarray)), c='red', alpha=0.7, linewidth=0.3)
ax1.set_xlim(0.01, 10000)
ax1.set_ylim(-0.1, 1.1)

leg = ax1.legend()
ax1.set_title("Power vs Pe")
ax1.legend()
plt.savefig('plot_allpec.pdf')
plt.show()

# ## Scatter plot values of work for all xcrit vs Pe
#
# combineddata = np.vstack((np.repeat(pecarray, 60), workvals))
# # transposed = np.transpose(combineddata)
# # separatedpairs = np.split(transposed, numvals)
# # print(separatedpairs[0])
# splitdata = np.array(np.split(combineddata, numvals, axis=1))
# weirdtranspose = splitdata.transpose(1, 0, 2)
# maxindex = np.where(weirdtranspose == np.amax(weirdtranspose))
#
# fig = plt.figure()
# ax1 = fig.add_subplot(111)
#
# ax1.set_title("Power vs Pe for multiple x_crit")
# ax1.set_xlabel('Peclet')
# ax1.set_ylabel('Average power output')
# ax1.set_xscale('log')
# ax1.set_yscale('linear')
# ax1.set_xlim(np.min(pecarray), np.max(pecarray))
# ax1.set_ylim(-0.1, 1.1)
# ax1.set_xlim(0.01, 10000)
#
# # # Generate points to plot
# # datapairs = np.array([pecarray[indices-1], highworkvals/(1*1/4)])
# # print(datapairs[0])
# # ax1.plot(datapairs[0][150:], 1- datapairs[0][150:]/8, c='olive', marker=',')
# # ax1.plot(datapairs[0][:60],  1-(1 - 4/(datapairs[0][:60])), c='olive', marker=',')
#
# ax1.scatter(combineddata[0],  4*combineddata[1], c='black', marker='o', s=(72./fig.dpi)**2)
# ax1.plot(combineddata[0],  np.ones(len(combineddata[0])), c='red', alpha=0.7, linewidth=0.3)
# ax1.plot(combineddata[0],  np.zeros(len(combineddata[0])), c='red', alpha=0.7, linewidth=0.3)
# plt.savefig('PowervsPe_multiple_xcrit.pdf')
# plt.show()